package com.example.test2.ui.wishlist;

import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import androidx.appcompat.widget.SearchView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.navigation.Navigation;

import com.example.test2.R;
import com.example.test2.databinding.FragmentWishlistBinding;

public class WishlistFragment extends Fragment {

    private FragmentWishlistBinding binding;
    ImageView imageView;
    private static final int PICK_IMAGE_REQUEST = 1;
    SearchView searchView;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {

        binding = FragmentWishlistBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        imageView = root.findViewById(R.id.imageView); // 레이아웃에 ImageView가 있다고 가정
        searchView = root.findViewById(R.id.search); // 레이아웃에 SearchView가 있다고 가정

        initSearchView();

        final TextView textView = binding.textWishlist;

        Button btnWishLists = binding.btnWishlists;
        Button btnCollections = binding.btnCollections;
        Button btnReg = binding.btnReg;

        btnReg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Navigation.findNavController(v).navigate(R.id.nav_wishlist_reg);
            }
        });


        btnWishLists.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                btnWishLists.setBackgroundColor(Color.parseColor("#FFFFFF"));
                btnCollections.setBackgroundColor(Color.parseColor("#D3D3D3"));
                // 메인 프레임을 가져옴
                FrameLayout mainFrame = root.findViewById(R.id.mainFrame);

                // 메인 프레임의 모든 뷰를 제거
                mainFrame.removeAllViews();

                // btn_wishlists 레이아웃을 인플레이트하고 메인 프레임에 추가
                View view = inflater.inflate(R.layout.btn_wishlists, mainFrame, true);
            }
        });

        btnCollections.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                btnCollections.setBackgroundColor(Color.parseColor("#FFFFFF"));
                btnWishLists.setBackgroundColor(Color.parseColor("#D3D3D3"));
                // 메인 프레임을 가져옴
                FrameLayout mainFrame = root.findViewById(R.id.mainFrame);

                // 메인 프레임의 모든 뷰를 제거
                mainFrame.removeAllViews();

                // btn_wishlists 레이아웃을 인플레이트하고 메인 프레임에 추가
                View view = inflater.inflate(R.layout.btn_collections, mainFrame, true);
            }
        });

        return root;
    }
    private void initSearchView() {
        androidx.appcompat.widget.SearchView searchViewAppcompat = (androidx.appcompat.widget.SearchView) searchView;
        searchViewAppcompat.setSubmitButtonEnabled(true);
        searchViewAppcompat.setOnQueryTextListener(new androidx.appcompat.widget.SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                return true;
            }
        });
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == PICK_IMAGE_REQUEST && resultCode == android.app.Activity.RESULT_OK && data != null) {
            Uri imageUri = data.getData();
            imageView.setImageURI(imageUri);
        }
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}